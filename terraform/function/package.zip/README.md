# How To udpate

In order to update this function, run the following commands : 

```
zip -ur package.zip * -x package.zip
```